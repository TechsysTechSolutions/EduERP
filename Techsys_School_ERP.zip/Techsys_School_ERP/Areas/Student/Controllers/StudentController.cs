﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Net.Mail;
using SendGrid;
using SendGrid.Helpers.Mail;
using System.Threading.Tasks;
using System.Net;
using System.Configuration;

namespace Techsys_School_ERP.Areas.Student.Controllers
{
    public class StudentController : Controller
    {
		// GET: Student/Student
		public async  Task<ActionResult> Index()
		{
			////"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"
			//var myMessage = new SendGrid.SendGridMessage();
			//myMessage.AddTo("test@sendgrid.com");
			//myMessage.From = new MailAddress("you@youremail.com", "First Last");
			//myMessage.Subject = "Sending with SendGrid is Fun";
			//myMessage.Text = "and easy to do anywhere, even with C#";
			//var key1 = "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";
			//var transportWeb = new SendGrid.Web(key1);
			//transportWeb.DeliverAsync(myMessage);

			var apiKey = "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";
			var client = new SendGridClient(apiKey);
			var from = new EmailAddress("deepikatulip@gmail.com", "Example User");
			var subject = "Sending with SendGrid is Fun";
			var to = new EmailAddress("deepikatulip@gmail.com", "Example User");
			var plainTextContent = "and easy to do anywhere, even with C#";
			var htmlContent = "<strong>and easy to do anywhere, even with C#</strong>";
			var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);
			var response = await client.SendEmailAsync(msg);


			//qPB_8U_eTYeiH0X0WkoeFg
			//var apikey = "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";
			////var apiKey = Environment.GetEnvironmentVariable("SENDGRID_KEY");
			//var client = new SendGridClient(apikey);
			//var from = new EmailAddress("deepikatulip@gmail.com", "Example User");
			//var subject = "Sending with SendGrid is Fun";
			//var to = new EmailAddress("deepikatulip@gmail.com", "Example User");
			//var plainTextContent = "and easy to do anywhere, even with C#";
			//var htmlContent = "<strong>and easy to do anywhere, even with C#</strong>";
			//var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);
			//var response = client.SendEmailAsync(msg);
	



			//// Create the email object first, then add the properties.
			//var myMessage = new SendGrid.SendGridMessage();

			//// Add the message properties.
			//myMessage.From = new MailAddress("deepikatulip@gmail.com");

			//// Add multiple addresses to the To field.
			//myMessage.AddTo("deepikatulip@gmail.com");

			//myMessage.Subject = "Password Recovery";

			////Add the HTML and Text bodies
			//myMessage.Html = "<p>Hello Sir/Madam</p>";
			//myMessage.Text = "Your Password is";

			//// Create network credentials to access your SendGrid account
			//var username = "deepikatulip";
			//var pswd = "techsys@2018";

			////var username = System.Environment.GetEnvironmentVariable("SENDGRID_USER");
			////var pswd = System.Environment.GetEnvironmentVariable("SENDGRID_PASS");
			////var apiKey = System.Environment.GetEnvironmentVariable("SENDGRID_APIKEY");



			//var credentials = new NetworkCredential(username, pswd);
			//// Create an Web transport for sending email.
			//var transportWeb = new Web(credentials);






			//Send Email
			//var mail = new MailMessage();
			//var smtpServer = new SmtpClient(ConfigurationManager.AppSettings["sendGridSmtpServer"]);
			//mail.From = new MailAddress(ConfigurationManager.AppSettings["sendGridFrom"]);

			//mail.To.Add("deepikatulip@gmail.com");
			//smtpServer.Port = Convert.ToInt32(ConfigurationManager.AppSettings["sendGridPort"]);
			//smtpServer.Credentials = new NetworkCredential(ConfigurationManager.AppSettings["sendGridUser"], ConfigurationManager.AppSettings["sendGridPassword"]);
			//smtpServer.EnableSsl = Convert.ToBoolean(ConfigurationManager.AppSettings["EnableSsl"]);

			//mail.Subject = "Subject here";
			//mail.Body = "Body message here";
			//mail.IsBodyHtml = true;
			//smtpServer.DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network;
			//smtpServer.ServicePoint.MaxIdleTime = 3;
			//smtpServer.DeliveryMethod = SmtpDeliveryMethod.PickupDirectoryFromIis;
			//smtpServer.Port = 587;
			//mail.Port = 587;

			//smtpServer.Send(mail);





			//try
			//{
			//	MailMessage mailMsg = new MailMessage();

			//	// To
			//	mailMsg.To.Add(new MailAddress("deepikatulip@example.com", "To Name"));

			//	// From
			//	mailMsg.From = new MailAddress("deepikatulip@example.com", "From Name");

			//	// Subject and multipart/alternative Body
			//	mailMsg.Subject = "subject";
			//	string text = "text body";
			//	string html = @"<p>html body</p>";
			//	//mailMsg.AlternateViews.Add(AlternateView.CreateAlternateViewFromString(text, null, MediaTypeNames.Text.Plain));
			//	//mailMsg.AlternateViews.Add(AlternateView.CreateAlternateViewFromString(html, null, MediaTypeNames.Text.Html));

			//	// Init SmtpClient and send
			//	SmtpClient smtpClient = new SmtpClient("smtp.sendgrid.net", Convert.ToInt32(587));
			//	System.Net.NetworkCredential credentials = new System.Net.NetworkCredential("deepikatulip@gmail.com", "techsys@2018");
			//	smtpClient.Credentials = credentials;

			//	smtpClient.Send(mailMsg);
			//}
			//catch (Exception ex)
			//{
			//	Console.WriteLine(ex.Message);
			//}

			return View();
		}

		//static async Index()
		//{
		//	var apiKey = System.Environment.GetEnvironmentVariable("SENDGRID_APIKEY");
		//	var client = new SendGridClient(apiKey);
		//	var msg = new SendGridMessage()
		//	{
		//		From = new EmailAddress("test@example.com", "DX Team"),
		//		Subject = "Hello World from the SendGrid CSharp SDK!",
		//		PlainTextContent = "Hello, Email!",
		//		HtmlContent = "<strong>Hello, Email!</strong>"
		//	};
		//	msg.AddTo(new EmailAddress("test@example.com", "Test User"));
		//	var response = await client.SendEmailAsync(msg);
		//}
	}
}